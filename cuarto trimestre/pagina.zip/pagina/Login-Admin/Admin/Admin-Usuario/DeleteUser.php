<?php

    echo("<script>
            alert('Boton Funciona para Delte')
            window.location.href = 'temp.html';
        </script>");

?>