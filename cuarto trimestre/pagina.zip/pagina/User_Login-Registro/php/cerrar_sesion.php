<?php

session_start();
session_destroy();
header("location:/texelyc.com/User_Login-Registro/User_Log-Reg.html" );

?>